// ================================================================
// TORN POKER SIDEKICK v6.1 — Content Script
// ================================================================
//
// DATA SOURCES (learned from real DOM outerHTML dump):
//
// BOARD  → .communityCards___cGHD3
//   Each card is a <li class="cardWrap___nAv2P card___TcIuJ">
//   Face-up cards: flipperWrap does NOT have flipped___ur6qi
//     and contain <div class="fourColors___ihYdi clubs-7___jeS4O ...">
//     The suit-rank is encoded as: (spades|hearts|diamonds|clubs)-(rank)
//   Face-down cards: flipperWrap HAS flipped___ur6qi → show card-back
//   Poll on interval — always reflects live state, no stale data.
//
// HOLE CARDS → v3 CSS class scraper (unchanged, confirmed working)
//   Reads [class*="___"] elements, walks up parent tree,
//   stops at community (board) elements so no bleed-through.
//
// LOG (.messagesWrap___tBx9u) → actions, reveals, win/new_hand resets ONLY
//   NOT used for board card values (log is history, often stale).
//   Log message structure confirmed from real outerHTML:
//     actor in <em>, text in <span><span>...</span></span>
//     "Game [hash] started" → new_hand reset
//     isWon class + "won $X with..." → win reset
//     "The flop/turn/river: " actor + suit spans → ignored (board comes from DOM)
//
// ================================================================
'use strict';

const SYM_TO_SUIT = {'♠':'spades','♥':'hearts','♦':'diamonds','♣':'clubs'};
const SUIT_SYM    = {spades:'♠',hearts:'♥',diamonds:'♦',clubs:'♣'};
const SUIT_COLOR  = {spades:'black',hearts:'red',diamonds:'red',clubs:'black'};
const RANK_VAL    = {'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,
                     '10':10,'J':11,'Q':12,'K':13,'A':14};

// Matches "clubs-7___jeS4O", "spades-5___giD5n", "diamonds-3___JlqYu"
// Used for BOTH board scraping and hole card scraping
const DOM_CARD_RE = /(spades|hearts|diamonds|clubs)-(A|K|Q|J|10|[2-9])/;

// ================================================================
// BOARD SCRAPER — reads .communityCards___cGHD3 directly
//
// Face-up card:   flipperWrap does NOT contain "flipped"
//                 → front div has fourColors___xxx suit-rank___hash
// Face-down card: flipperWrap contains "flipped___ur6qi"
//                 → just a back image, no card data
//
// Returns array of {rank, suit} for revealed cards only.
// Returns null if the community card container isn't found yet.
// ================================================================
function scrapeBoardCards() {
  const wrap = document.querySelector('.communityCards___cGHD3');
  if (!wrap) return null;

  const cards = [];
  // Each card slot is a <li class="cardWrap___nAv2P card___TcIuJ">
  const slots = wrap.querySelectorAll('[class*="cardWrap"]');

  for (const slot of slots) {
    // The flipper wrapper tells us if the card is face-up or face-down
    const flipperWrap = slot.querySelector('[class*="flipperWrap"]');
    if (!flipperWrap) continue;
    // flipped___ur6qi means the card is face-down (back showing)
    if (flipperWrap.className.includes('flipped')) continue;

    // Face-up: find the fourColors div — its class encodes suit-rank
    // e.g. "fourColors___ihYdi clubs-7___jeS4O cardSize___BbTMe"
    const faceDiv = slot.querySelector('[class*="fourColors"]');
    if (!faceDiv) continue;

    const m = DOM_CARD_RE.exec(faceDiv.className);
    if (m) {
      cards.push({ rank: m[2], suit: m[1] });
    }
  }

  return cards;
}

// ================================================================
// HERO HOLE CARD SCRAPER (unchanged from v3 — confirmed working)
//
// Reads [class*="___"] elements for suit-rank CSS class names.
// Walks up parent tree:
//   - stops (card IS hole) if parent has hole/pocket/hero/self/etc
//   - stops (card NOT hole) if parent has community/board/shared/etc
//     ← .communityCards___cGHD3 matches "community" → board cards
//        are correctly excluded
// ================================================================
function scrapeHeroCards() {
  const holeCards = [];
  const all = document.querySelectorAll('[class*="___"]');
  for (const el of all) {
    const m = DOM_CARD_RE.exec(el.className);
    if (!m) continue;
    const card = { rank: m[2], suit: m[1] };
    let node = el, isHole = false;
    for (let i = 0; i < 10; i++) {
      node = node.parentElement;
      if (!node) break;
      const cls = (node.className || '').toLowerCase() + (node.id || '').toLowerCase();
      if (/hole|pocket|hero|self|mycard|yourcard|handcard/.test(cls)) { isHole = true; break; }
      if (/community|board|shared|flop|turn|river/.test(cls)) break;
    }
    if (isHole && holeCards.length < 2) holeCards.push(card);
  }
  return holeCards;
}

function parseDollars(t) {
  const m = t.match(/\$([0-9,]+)/);
  return m ? parseInt(m[1].replace(/,/g, ''), 10) : 0;
}

// ================================================================
// TORN LOG OBSERVER
// Only used for: new_hand resets, win resets, player actions,
// reveal events. Board card values no longer come from here.
//
// Dedup: tracks message count. On each mutation, processes only
// new messages appended after the last known count. This is safe
// because Torn appends to the log — it doesn't edit old messages.
// ================================================================
class TornLogObserver {
  constructor(onEvents) {
    this.onEvents   = onEvents;
    this._processed = 0;  // count of messages already handled
    this._mo        = null;
  }

  findWrap() {
    const el = document.querySelector('.messagesWrap___tBx9u');
    if (el) return el;
    for (const c of document.querySelectorAll('div,section')) {
      if (c.children.length > 4 &&
          c.querySelector('[class*="suite"]') &&
          c.querySelector('em')) return c;
    }
    return null;
  }

  start(wrapEl) {
    this._wrapEl = wrapEl;
    this._flush(wrapEl);
    this._mo = new MutationObserver(() => this._flush(wrapEl));
    this._mo.observe(wrapEl, { childList: true, subtree: true });
  }

  _flush(wrapEl) {
    const msgs = Array.from(wrapEl.querySelectorAll('.message___RlFXd'));
    if (msgs.length <= this._processed) return;

    const newMsgs = msgs.slice(this._processed);
    this._processed = msgs.length;

    const evts = [];
    for (const msg of newMsgs) {
      const ev = this._parse(msg);
      if (ev) evts.push(ev);
    }
    if (evts.length) this.onEvents(evts);
  }

  _parse(msg) {
    const isState = msg.classList.contains('state___dS3_T');
    const isWon   = msg.classList.contains('won___fMZlR');
    const actor   = msg.querySelector('em')?.textContent?.trim() ?? '';
    const text    = msg.querySelector(':scope > span')?.textContent?.trim() ?? '';

    // "Game 5e031cc94f1998831d9ef124bafb4f started"
    if (actor === 'Game' && /^[a-f0-9]+\s+started$/i.test(text))
      return { type: 'new_hand' };

    // Winner row — has class won___fMZlR, text starts with "won"
    if (isWon && actor && /^won\b/i.test(text))
      return { type: 'win', player: actor, amount: parseDollars(text) };

    // Reveal: state message, player actor, contains "reveals"
    if (isState && actor && !actor.startsWith('The ') && actor !== 'Game' && text.includes('reveals')) {
      // Extract hole cards from the log reveal line using suit spans
      const cards = extractCardsFromLogMsg(msg);
      const hm    = text.match(/\(([^)]+)\)/);
      if (cards.length >= 2)
        return { type: 'reveal', player: actor, cards, handName: hm?.[1] ?? '' };
    }

    // Skip board phase markers — board comes from DOM, not log
    if (isState) return null;

    // Skip non-player lines
    if (!actor || actor === 'Game' || actor.startsWith('The ')) return null;

    // Player actions
    if (text.startsWith('posted big blind'))   return { type:'action', player:actor, action:'bigblind',   amount:parseDollars(text) };
    if (text.startsWith('posted small blind')) return { type:'action', player:actor, action:'smallblind', amount:parseDollars(text) };
    if (text.startsWith('posted'))             return { type:'action', player:actor, action:'post',       amount:parseDollars(text) };
    if (text.startsWith('bet'))                return { type:'action', player:actor, action:'bet',        amount:parseDollars(text) };
    if (/^raised?/i.test(text))                return { type:'action', player:actor, action:'raise',      amount:parseDollars(text) };
    if (text.startsWith('called'))             return { type:'action', player:actor, action:'call',       amount:parseDollars(text) };
    if (text === 'checked')                    return { type:'action', player:actor, action:'check',      amount:0 };
    if (text === 'folded')                     return { type:'action', player:actor, action:'fold',       amount:0 };
    if (text.includes('joined'))               return { type:'action', player:actor, action:'join',       amount:0 };
    return null;
  }
}

// Extract cards from a log message element (used only for reveal lines)
// Structure: <span><span>K</span><span class="suite___BhNsx red___vgg7x">♦</span><span>, 7</span>...
function extractCardsFromLogMsg(msgEl) {
  const cards = [];
  const suitSpans = msgEl.querySelectorAll('[class*="suite"]');
  for (const sp of suitSpans) {
    const suit = SYM_TO_SUIT[sp.textContent.trim()];
    if (!suit) continue;
    let rank = '';
    let node = sp.previousSibling;
    while (node) {
      const t = (node.textContent || '').replace(/[,\s\[\]()]/g, '');
      const m = t.match(/(10|[2-9AKQJ])$/i);
      if (m) { rank = m[1].toUpperCase(); break; }
      if (node.nodeType === Node.ELEMENT_NODE && (node.className||'').includes('suite')) break;
      node = node.previousSibling;
    }
    if (rank && suit && RANK_VAL[rank] !== undefined)
      cards.push({ rank, suit });
  }
  return cards;
}

// ================================================================
// HAND ASSEMBLER (unchanged from v3)
// ================================================================
class HandAssembler {
  constructor() { this.reset(); }
  reset() {
    this.hand = {
      id: Date.now()+Math.random(), ts: new Date().toISOString(),
      street: 'preflop', board: [], players: {}, actions: [],
      winners: [], heroCards: null, complete: false, isObserved: true
    };
    this.currentStreet = 'preflop';
  }
  ingest(ev) {
    const h = this.hand;
    if (ev.type === 'new_hand') { const old = this.finalise(); this.reset(); return old; }
    if (ev.type === 'reveal') {
      if (!h.players[ev.player]) h.players[ev.player] = { cards:[], handName:'', actions:[] };
      h.players[ev.player].cards    = ev.cards;
      h.players[ev.player].handName = ev.handName;
    }
    if (ev.type === 'win') {
      h.winners.push(ev.player);
    }
    if (ev.type === 'action') {
      if (!h.players[ev.player]) h.players[ev.player] = { cards:[], handName:'', actions:[] };
      h.players[ev.player].actions.push({ street: this.currentStreet, action: ev.action, amount: ev.amount });
      h.actions.push({ street: this.currentStreet, ...ev });
    }
  }
  // Called externally with the board snapshot at end of hand
  setBoard(board) { this.hand.board = [...board]; }
  finalise() {
    const h = this.hand;
    if (!Object.keys(h.players).length) return null;
    if (!Object.values(h.players).some(p => p.cards.length >= 2)) return null;
    h.complete = true; return { ...h };
  }
}

// ================================================================
// OPPONENT PROFILER (unchanged from v3)
// ================================================================
class OpponentProfiler {
  constructor() { this.profiles = {}; this._load(); }
  _load() { try { this.profiles = JSON.parse(localStorage.getItem('psk_opponents')||'{}'); } catch(e){} }
  save()  { try { localStorage.setItem('psk_opponents', JSON.stringify(this.profiles)); } catch(e){} }
  get(name) {
    if (!this.profiles[name])
      this.profiles[name] = { name, actions:[], reveals:[], handsPlayed:0, wins:0, lastSeen:0 };
    return this.profiles[name];
  }
  recordAction(name, action, street, amount) {
    const p = this.get(name);
    p.actions.push({ action, street, amount, ts: Date.now() });
    if (p.actions.length > 2000) p.actions = p.actions.slice(-2000);
    p.lastSeen = Date.now();
  }
  recordReveal(name, cards, handName, won) {
    const p = this.get(name);
    p.reveals.push({ cards, handName, won, ts: Date.now() });
    if (p.reveals.length > 500) p.reveals = p.reveals.slice(-500);
    p.handsPlayed++; if (won) p.wins++;
  }
  classify(name) {
    const p = this.get(name), a = p.actions;
    if (a.length < 6) return { label:'Unknown', icon:'❓', color:'#556677' };
    const tot=a.length, rz=a.filter(x=>x.action==='raise').length,
          cl=a.filter(x=>x.action==='call').length, fd=a.filter(x=>x.action==='fold').length;
    const rr=rz/tot, fr=fd/tot;
    let label, icon, color;
    if (rr>0.42)               { label='Maniac';     icon='💣'; color='#ff2244'; }
    else if (rr>0.26&&fr<0.40) { label='Aggressive'; icon='🔥'; color='#ff6030'; }
    else if (fr>0.68)          { label='Nit';        icon='🐢'; color='#3090ff'; }
    else if (rr>0.18&&fr<0.46) { label='TAG';        icon='🎯'; color='#00e887'; }
    else if (rr<0.10&&fr<0.32) { label='Station';    icon='📞'; color='#ffcc00'; }
    else if (fr>0.50)          { label='Passive';    icon='👻'; color='#8899aa'; }
    else                       { label='Balanced';   icon='⚖️'; color='#aa88ff'; }
    const vpip=Math.round((rz+cl)/tot*100), pfr=Math.round(rz/tot*100);
    const af=cl>0?+(rz/cl).toFixed(1):rz>0?'∞':0;
    return { label, icon, color, vpip, pfr, af, handsPlayed:p.handsPlayed, wins:p.wins };
  }
}

// ================================================================
// HAND EVALUATOR + MONTE CARLO (unchanged from v3)
// ================================================================
class HandEvaluator {
  eval(hole, board) {
    const all = [...(hole||[]), ...(board||[])];
    if (all.length < 2) return { rank:-1, name:'—', strength:0 };
    const k = Math.min(5, all.length);
    let best = { rank:-1, name:'', strength:0 };
    for (const c of this._combos(all, k)) {
      const r = this._eval5(c);
      if (r.rank > best.rank || (r.rank===best.rank && r.strength>best.strength)) best = r;
    }
    return best;
  }
  _eval5(cards) {
    const rv = c => RANK_VAL[c.rank] || parseInt(c.rank) || 0;
    const ranks = cards.map(rv).sort((a,b)=>b-a);
    const suits = cards.map(c=>c.suit);
    const isF   = suits.length>=5 && suits.every(s=>s===suits[0]);
    const rc    = {}; ranks.forEach(r=>rc[r]=(rc[r]||0)+1);
    const cnts  = Object.values(rc).sort((a,b)=>b-a);
    const isSt  = this._straight(ranks);
    if (isF&&isSt&&ranks[0]===14) return {rank:9,name:'Royal Flush',  strength:1.000};
    if (isF&&isSt)                return {rank:8,name:'Straight Flush',strength:.970+ranks[0]/1e3};
    if (cnts[0]===4)              return {rank:7,name:'Four of a Kind',strength:.940+ranks[0]/1e3};
    if (cnts[0]===3&&cnts[1]===2)return {rank:6,name:'Full House',    strength:.910+ranks[0]/1e3};
    if (isF)                      return {rank:5,name:'Flush',         strength:.820+ranks[0]/1e3};
    if (isSt)                     return {rank:4,name:'Straight',      strength:.720+ranks[0]/1e3};
    if (cnts[0]===3)              return {rank:3,name:'Three of a Kind',strength:.620+ranks[0]/1e3};
    if (cnts[0]===2&&cnts[1]===2)return {rank:2,name:'Two Pair',      strength:.480+ranks[0]/1e3};
    if (cnts[0]===2) {
      const pr = +Object.entries(rc).find(([,v])=>v===2)?.[0]||0;
      return {rank:1,name:'One Pair',strength:.32+pr/100};
    }
    return {rank:0,name:'High Card',strength:ranks[0]/100};
  }
  _straight(s) {
    if (s.length<5) return false;
    const t = s.slice(0,5);
    if (t[0]-t[4]===4 && new Set(t).size===5) return true;
    if (s[0]===14 && s[s.length-1]===2 && s.slice(1,5).join()===s.filter(r=>r<=5).slice(0,4).join()) return true;
    return false;
  }
  _combos(arr, k) {
    if (k>=arr.length) return [arr];
    if (k===1) return arr.map(x=>[x]);
    const r=[];
    for (let i=0;i<=arr.length-k;i++)
      this._combos(arr.slice(i+1),k-1).forEach(t=>r.push([arr[i],...t]));
    return r;
  }
  equity(hole, board, numOpp=1, sims=800) {
    if (!hole||hole.length<2) return null;
    const deck = this._buildDeck([...hole,...(board||[])]);
    let wins=0, ties=0;
    for (let i=0;i<sims;i++) {
      const d = this._shuffle([...deck]);
      const needed = 5-(board||[]).length;
      const brd = [...(board||[]),...d.slice(0,needed)];
      const mine = this.eval(hole,brd);
      let iWin=true, isTie=false; let ptr=needed;
      for (let o=0;o<numOpp;o++) {
        const oh=d.slice(ptr,ptr+2); ptr+=2;
        if (oh.length<2) break;
        const opp=this.eval(oh,brd);
        if (opp.rank>mine.rank||(opp.rank===mine.rank&&opp.strength>mine.strength)){iWin=false;break;}
        if (opp.rank===mine.rank&&Math.abs(opp.strength-mine.strength)<.001) isTie=true;
      }
      if (iWin&&!isTie) wins++; else if (isTie) ties++;
    }
    return { win:wins/sims, tie:ties/sims, lose:(sims-wins-ties)/sims };
  }
  _buildDeck(exclude) {
    const ranks=['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
    const suits=['spades','hearts','diamonds','clubs'];
    const ex=new Set(exclude.map(c=>c.rank+'|'+c.suit));
    const d=[];
    for (const r of ranks) for (const s of suits)
      if (!ex.has(r+'|'+s)) d.push({rank:r,suit:s});
    return d;
  }
  _shuffle(a) {
    for (let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}
    return a;
  }
}

// ================================================================
// HAND STORE (unchanged from v3)
// ================================================================
class HandStore {
  constructor() { this.hands=[]; this._load(); }
  _load() { try{this.hands=JSON.parse(localStorage.getItem('psk_hands')||'[]');}catch(e){} }
  save()  { try{localStorage.setItem('psk_hands',JSON.stringify(this.hands.slice(-5000)));}catch(e){} }
  add(hand) {
    if (this.hands.find(h=>h.id===hand.id)) return;
    this.hands.push(hand); this.save();
  }
  stats() {
    const t=this.hands.length;
    const heroHands=this.hands.filter(h=>!h.isObserved);
    const hw=heroHands.filter(h=>h.winners.includes('hero')||h.winners.includes(h.heroName)).length;
    return {
      total:t, observed:this.hands.filter(h=>h.isObserved).length,
      heroHands:heroHands.length, heroWins:hw,
      heroWinRate:heroHands.length?(hw/heroHands.length*100).toFixed(1):'0'
    };
  }
  export() { return JSON.stringify(this.hands,null,2); }
}

// ================================================================
// BAYESIAN MODEL (unchanged from v3)
// ================================================================
class BayesModel {
  constructor() {
    this.data = { handWins:{}, handTotal:{}, oppFoldRate:{}, positionWins:{}, positionTotal:{} };
    this._load();
  }
  _load() {
    try {
      this.data = JSON.parse(localStorage.getItem('psk_model_data')||'{}');
      ['handWins','handTotal','oppFoldRate','positionWins','positionTotal']
        .forEach(k => this.data[k] = this.data[k]||{});
    } catch(e){}
  }
  save() { try{localStorage.setItem('psk_model_data',JSON.stringify(this.data));}catch(e){} }
  learn(hand, evaluator) {
    for (const [name,pdata] of Object.entries(hand.players)) {
      if (pdata.cards.length<2) continue;
      const won=hand.winners.includes(name);
      const ev=evaluator.eval(pdata.cards,hand.board);
      const bucket=`rank_${ev.rank}`;
      this.data.handWins[bucket]=(this.data.handWins[bucket]||0)+(won?1:0);
      this.data.handTotal[bucket]=(this.data.handTotal[bucket]||0)+1;
      const [c1,c2]=[...pdata.cards].sort((a,b)=>RANK_VAL[b.rank]-RANK_VAL[a.rank]);
      const suited=c1.suit===c2.suit?'s':'o';
      const hkey=`${c1.rank}${c2.rank}_${suited}`;
      this.data.handWins[hkey]=(this.data.handWins[hkey]||0)+(won?1:0);
      this.data.handTotal[hkey]=(this.data.handTotal[hkey]||0)+1;
    }
    this.save();
  }
  holecardPrior(hole) {
    if (!hole||hole.length<2) return null;
    const [c1,c2]=[...hole].sort((a,b)=>RANK_VAL[b.rank]-RANK_VAL[a.rank]);
    const s=c1.suit===c2.suit?'s':'o';
    const key=`${c1.rank}${c2.rank}_${s}`;
    const wins=this.data.handWins[key]||0, tot=this.data.handTotal[key]||0;
    if (tot<3) return null;
    return { rate:wins/tot, samples:tot, key };
  }
  accuracy() {
    let ok=0,tot=0;
    for (const key of ['rank_0','rank_1','rank_2','rank_3','rank_4','rank_5','rank_6','rank_7','rank_8','rank_9']) {
      const w=this.data.handWins[key]||0, t=this.data.handTotal[key]||0;
      if (!t) continue;
      const wr=w/t, expected=key>='rank_4'?1:0, predicted=wr>.5?1:0;
      if (predicted===expected) ok++; tot++;
    }
    return tot>0?ok/tot:null;
  }
}

// ================================================================
// OVERLAY UI (unchanged from v3)
// ================================================================
class Overlay {
  constructor() { this._inject(); }
  _inject() {
    document.getElementById('psk')?.remove();
    document.getElementById('psk-css')?.remove();
    const style=document.createElement('style');
    style.id='psk-css'; style.textContent=this._css();
    document.head.appendChild(style);
    const root=document.createElement('div');
    root.id='psk'; root.innerHTML=this._html();
    document.body.appendChild(root);
    this._bind(root); this.root=root;
  }
  _html(){return`
<div id="psk-box">
  <div id="psk-hdr">
    <span id="psk-logo">♠ SIDEKICK</span>
    <div><span id="psk-obs-badge" title="Observing">👁</span><span id="psk-min" title="Minimize">─</span></div>
  </div>
  <div id="psk-body">
    <div class="pl">STREET</div>
    <div id="psk-street">Watching...</div>
    <div class="pl" style="margin-top:8px">YOUR CARDS</div>
    <div id="psk-hole" class="psk-crow"><span class="pce">?</span><span class="pce">?</span></div>
    <div class="pl" style="margin-top:6px">BOARD</div>
    <div id="psk-board" class="psk-crow">
      <span class="pce">?</span><span class="pce">?</span><span class="pce">?</span><span class="pce">?</span><span class="pce">?</span>
    </div>
    <div id="psk-handname">—</div>
    <div id="psk-eq-wrap">
      <div id="psk-eq-bar-bg"><div id="psk-eq-bar"></div></div>
      <div id="psk-eq-nums">
        <div><span id="eq-w">—</span><div class="el">WIN</div></div>
        <div><span id="eq-t">—</span><div class="el">TIE</div></div>
        <div><span id="eq-l">—</span><div class="el">LOSE</div></div>
      </div>
    </div>
    <div id="psk-prior"></div>
    <div id="psk-advice"></div>
    <div class="pl" style="margin-top:8px">AT TABLE</div>
    <div id="psk-opps"></div>
    <div id="psk-log-section">
      <div class="pl" style="margin-top:8px">LAST REVEALS</div>
      <div id="psk-reveals"></div>
    </div>
    <div id="psk-foot">
      <span id="psk-stat">0 hands</span>
      <button id="psk-exp">⬇ Export</button>
    </div>
  </div>
</div>`;}
  _css(){return`
#psk{position:fixed;top:80px;right:16px;z-index:2147483647;font-family:'Courier New',monospace;font-size:11px;user-select:none;}
#psk-box{width:220px;background:#08101e;border:1px solid #1a3a5c;border-radius:10px;box-shadow:0 0 28px rgba(0,180,255,.1),0 4px 24px rgba(0,0,0,.7);overflow:hidden;}
#psk-hdr{display:flex;justify-content:space-between;align-items:center;padding:7px 11px;background:#0b1828;border-bottom:1px solid #1a3a5c;cursor:move;}
#psk-logo{color:#00c8ff;font-weight:bold;font-size:10px;letter-spacing:2.5px;}
#psk-hdr div{display:flex;gap:8px;align-items:center;}
#psk-obs-badge{font-size:13px;cursor:default;}
#psk-min{color:#00c8ff;cursor:pointer;font-size:15px;line-height:1;}
#psk-min:hover{color:#fff;}
#psk-body{padding:9px 10px;}
#psk-box.mini #psk-body{display:none;}
.pl{font-size:8px;letter-spacing:2px;color:#2a5070;margin-bottom:3px;}
#psk-street{color:#00c8ff;font-size:10px;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:4px;}
.psk-crow{display:flex;gap:3px;flex-wrap:wrap;margin-bottom:2px;}
.pc{display:inline-flex;flex-direction:column;align-items:center;justify-content:center;width:32px;height:44px;background:#fff;border-radius:4px;font-family:Georgia,serif;font-weight:bold;box-shadow:0 2px 6px rgba(0,0,0,.5);transition:transform .15s;line-height:1;}
.pc:hover{transform:translateY(-3px);}
.pc .pr{font-size:12px;}.pc .ps{font-size:11px;}
.pc.red{color:#cc0000;}.pc.black{color:#111133;}
.pc.hole{border:2px solid #ffcc00;}
.pce{display:inline-flex;align-items:center;justify-content:center;width:32px;height:44px;background:#0d1e30;border:1px solid #1a3a5c;border-radius:4px;color:#1a3a5c;font-size:16px;}
#psk-handname{font-size:13px;font-weight:bold;color:#fff;margin:8px 0 5px;letter-spacing:.3px;}
#psk-eq-wrap{margin-bottom:7px;}
#psk-eq-bar-bg{height:5px;background:#0d1e30;border-radius:3px;overflow:hidden;margin-bottom:5px;}
#psk-eq-bar{height:100%;width:0;border-radius:3px;transition:width .5s,background .5s;background:linear-gradient(90deg,#004418,#00e887);}
#psk-eq-nums{display:grid;grid-template-columns:1fr 1fr 1fr;text-align:center;font-size:11px;font-weight:bold;}
#psk-eq-nums>div{display:flex;flex-direction:column;align-items:center;}
#eq-w{color:#00e887;}#eq-t{color:#ffcc00;}#eq-l{color:#ff4060;}
.el{font-size:7px;color:#2a5070;letter-spacing:1px;}
#psk-prior{font-size:10px;color:#aa88ff;margin-bottom:4px;min-height:0;}
#psk-advice{background:#0b1828;border:1px solid #1a3a5c;border-radius:5px;padding:6px 8px;margin:6px 0;font-size:10px;color:#c0d8e8;line-height:1.45;min-height:28px;}
.abad{display:inline-block;margin-top:4px;padding:1px 8px;border-radius:3px;font-size:9px;font-weight:bold;letter-spacing:1px;}
.af{background:#3a0010;color:#ff4060;border:1px solid #ff4060;}
.ac{background:#3a2e00;color:#ffcc00;border:1px solid #ffcc00;}
.ar{background:#003a15;color:#00e887;border:1px solid #00e887;}
.psk-opp{display:flex;align-items:center;justify-content:space-between;padding:3px 0;border-bottom:1px solid #0d1e30;font-size:10px;}
.psk-opp:last-child{border:none;}
.psk-on{color:#8899aa;flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;}
.psk-ot{font-size:8px;padding:1px 5px;border-radius:3px;white-space:nowrap;margin-left:4px;letter-spacing:.3px;}
.rev-row{font-size:9px;color:#556677;padding:2px 0;border-bottom:1px solid #0d1520;line-height:1.4;}
.rev-row:last-child{border:none;}
.rev-cards{color:#ffcc00;}
.rev-won{color:#00e887;}.rev-lost{color:#ff4060;}
#psk-foot{display:flex;justify-content:space-between;align-items:center;border-top:1px solid #1a3a5c;padding-top:6px;margin-top:6px;}
#psk-stat{color:#2a5070;font-size:9px;}
#psk-exp{background:#0b1828;border:1px solid #1a3a5c;color:#00c8ff;padding:2px 8px;border-radius:3px;cursor:pointer;font-family:'Courier New',monospace;font-size:9px;letter-spacing:1px;}
#psk-exp:hover{background:#1a3a5c;}
`;}
  _bind(root) {
    let drag=false,ox=0,oy=0;
    root.querySelector('#psk-hdr').addEventListener('mousedown',e=>{
      drag=true;ox=e.clientX-root.offsetLeft;oy=e.clientY-root.offsetTop;e.preventDefault();
    });
    document.addEventListener('mousemove',e=>{if(!drag)return;
      root.style.right='auto';
      root.style.left=Math.max(0,e.clientX-ox)+'px';
      root.style.top=Math.max(0,e.clientY-oy)+'px';
    });
    document.addEventListener('mouseup',()=>drag=false);
    root.querySelector('#psk-min').addEventListener('click',()=>
      root.querySelector('#psk-box').classList.toggle('mini'));
  }
  cardHTML(c, isHole=false) {
    const sym = SUIT_SYM[c.suit]||c.suit;
    const col = SUIT_COLOR[c.suit]||'black';
    return `<span class="pc ${col}${isHole?' hole':''}"><span class="pr">${c.rank}</span><span class="ps">${sym}</span></span>`;
  }
  cardStr(c) { return c.rank+(SUIT_SYM[c.suit]||c.suit[0]); }
  update({street,hole,board,handResult,equity,prior,advice,players,reveals,stats,isSeated}) {
    const $=id=>document.getElementById(id);
    $('psk-obs-badge').textContent=isSeated?'🪑':'👁';
    $('psk-obs-badge').title=isSeated?'Seated & playing':'Observing only';
    const smap={preflop:'PRE-FLOP',flop:'FLOP',turn:'TURN',river:'RIVER',showdown:'SHOWDOWN'};
    $('psk-street').textContent=smap[street]||'WAITING...';
    $('psk-hole').innerHTML=(hole||[]).length>=2
      ?hole.map(c=>this.cardHTML(c,true)).join('')
      :'<span class="pce">?</span><span class="pce">?</span>';
    let bh=(board||[]).slice(0,5).map(c=>this.cardHTML(c)).join('');
    for(let i=(board||[]).length;i<5;i++) bh+='<span class="pce">?</span>';
    $('psk-board').innerHTML=bh;
    $('psk-handname').textContent=handResult?.name||'—';
    if(equity){
      const wp=Math.round(equity.win*100);
      const bar=$('psk-eq-bar');
      bar.style.width=wp+'%';
      bar.style.background=wp>65?'linear-gradient(90deg,#003a12,#00e887)':wp>40?'linear-gradient(90deg,#3a2a00,#ffcc00)':'linear-gradient(90deg,#3a0010,#ff4060)';
      $('eq-w').textContent=wp+'%';
      $('eq-t').textContent=Math.round(equity.tie*100)+'%';
      $('eq-l').textContent=Math.round(equity.lose*100)+'%';
    }
    $('psk-prior').textContent=prior?`Model: ${Math.round(prior.rate*100)}% WR on ${prior.key} (${prior.samples} hands)`:'';
    $('psk-advice').innerHTML=advice||'🃏 Watching the table...';
    const od=$('psk-opps');
    if(players&&players.length){
      od.innerHTML=players.slice(0,6).map(p=>`
        <div class="psk-opp">
          <span class="psk-on" title="${p.name}">${p.name.slice(0,14)}</span>
          <span class="psk-ot" style="background:${p.cl.color}22;color:${p.cl.color};border:1px solid ${p.cl.color}44">${p.cl.icon} ${p.cl.label}</span>
        </div>`).join('');
    } else {
      od.innerHTML='<div style="color:#2a5070;font-size:9px;padding:3px 0">Reading table...</div>';
    }
    const rd=$('psk-reveals');
    if(reveals&&reveals.length){
      rd.innerHTML=reveals.slice(0,5).map(r=>`
        <div class="rev-row">
          <span class="${r.won?'rev-won':'rev-lost'}">${r.won?'✅':'❌'}</span>
          <b style="color:#8899aa"> ${r.player.slice(0,10)}</b>
          <span class="rev-cards"> ${r.cards.map(c=>this.cardStr(c)).join(' ')}</span>
          <span style="color:#445566"> ${r.handName||''}</span>
        </div>`).join('');
    }
    $('psk-stat').textContent=`${stats.total} hands (${stats.observed} obs)`;
  }
  setExportHandler(fn) { document.getElementById('psk-exp').addEventListener('click',fn); }
}

// ================================================================
// MAIN SIDEKICK v6.1
// ================================================================
class PokerSidekick {
  constructor() {
    this.assembler  = new HandAssembler();
    this.profiler   = new OpponentProfiler();
    this.evaluator  = new HandEvaluator();
    this.store      = new HandStore();
    this.model      = new BayesModel();
    this.overlay    = new Overlay();
    this.tornObs    = new TornLogObserver(evts => this._processLogEvents(evts));

    this.board          = [];   // live board — from DOM scrape
    this.street         = 'preflop';
    this.heroHole       = [];
    this.recentReveals  = [];
    this.players        = [];
    this.pot            = 0;

    this.overlay.setExportHandler(() => this._export());
    this._boot();
    console.log('%c♠ Torn Poker Sidekick v6.1 — DOM board scraper active','color:#00c8ff;font-weight:bold;font-size:13px');
  }

  _export() {
    const blob=new Blob([this.store.export()],{type:'application/json'});
    const a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download=`torn_poker_${Date.now()}.json`;
    a.click();
  }

  _boot() {
    const try_ = () => {
      const wrap = this.tornObs.findWrap();
      if (wrap) {
        console.log('[PSK v6.1] Log container found');
        this.tornObs.start(wrap);
        this._startPolling();
      } else {
        setTimeout(try_, 1500);
      }
    };
    setTimeout(try_, 2500);
  }

  _startPolling() {
    let lastHoleKey = '';
    let lastBoardKey = '';

    setInterval(() => {
      try {
        // ── Hole cards (v3 scraper, unchanged) ─────────────────
        const scraped = scrapeHeroCards();
        const holeKey = scraped.map(c=>c.rank+'|'+c.suit).join(',');
        if (holeKey !== lastHoleKey) {
          lastHoleKey = holeKey;
          this.heroHole = scraped;
          if (scraped.length > 0) {
            this.assembler.hand.heroCards  = scraped;
            this.assembler.hand.isObserved = false;
          }
        }

        // ── Board (new DOM scraper) ──────────────────────────────
        // scrapeBoardCards() reads .communityCards___cGHD3 directly.
        // Returns null if container not present, [] if no cards up yet.
        const scraped_board = scrapeBoardCards();
        if (scraped_board !== null) {
          const boardKey = scraped_board.map(c=>c.rank+'|'+c.suit).join(',');
          if (boardKey !== lastBoardKey) {
            lastBoardKey = boardKey;
            this.board = scraped_board;
            // Update street from board length
            if (scraped_board.length === 0)      this.street = 'preflop';
            else if (scraped_board.length === 3)  this.street = 'flop';
            else if (scraped_board.length === 4)  this.street = 'turn';
            else if (scraped_board.length === 5)  this.street = 'river';
            // Sync to assembler for hand recording
            this.assembler.setBoard(this.board);
          }
        }

        this._render();
      } catch(e) {}
    }, 700);
  }

  // Log events: new_hand/win resets + actions + reveals
  // Board values are NOT read from the log anymore
  _processLogEvents(evts) {
    for (const ev of evts) {

      if (ev.type === 'new_hand') {
        // Board will naturally go to 0 cards as Torn resets the community cards DOM
        // We still reset our tracking state
        this.street        = 'preflop';
        this.recentReveals = [];
        this.players       = [];
        this.pot           = 0;
        const old = this.assembler.ingest(ev);
        if (old) this._onHandComplete(old);
        continue;
      }

      if (ev.type === 'win') {
        // Board DOM will go back to all face-down after hand ends
        // recentReveals winner marking
        this.recentReveals.forEach(r => { if (r.player === ev.player) r.won = true; });
        this.street = 'showdown';
        this.assembler.ingest(ev);
        continue;
      }

      if (ev.type === 'reveal') {
        this.recentReveals.unshift({ player:ev.player, cards:ev.cards, handName:ev.handName, won:false });
        if (this.recentReveals.length > 8) this.recentReveals.pop();
        this.assembler.ingest(ev);
        continue;
      }

      if (ev.type === 'action') {
        if (ev.amount) this.pot += ev.amount;
        this.profiler.recordAction(ev.player, ev.action, this.street, ev.amount);
        this.profiler.save();
        if (!this.players.includes(ev.player)) this.players.push(ev.player);
        if (ev.action === 'win') this.recentReveals.forEach(r => { if (r.player===ev.player) r.won=true; });
        this.assembler.ingest(ev);
        continue;
      }
    }
    this._broadcastToDashboard();
  }

  _onHandComplete(hand) {
    for (const [name,pdata] of Object.entries(hand.players)) {
      if (pdata.cards.length < 2) continue;
      this.profiler.recordReveal(name, pdata.cards, pdata.handName, hand.winners.includes(name));
    }
    this.profiler.save();
    this.store.add(hand);
    this.model.learn(hand, this.evaluator);
    this._broadcastToDashboard();
    console.log(`[PSK v6.1] Hand complete — winners: ${hand.winners.join(', ')}`);
  }

  _broadcastToDashboard() {
    try {
      localStorage.setItem('psk_live', JSON.stringify({
        board:this.board, heroHole:this.heroHole, street:this.street,
        players:this.players, reveals:this.recentReveals,
        pot:this.pot, stats:this.store.stats(), ts:Date.now()
      }));
    } catch(e){}
  }

  _render() {
    const hole=this.heroHole, board=this.board, street=this.street;
    const isSeated=hole.length>=2;
    let handResult=null,equity=null,prior=null,advice='🃏 Watching the table...';

    if (hole.length >= 2) {
      handResult = this.evaluator.eval(hole, board);
      const numOpp = Math.max(1, this.players.length-1);
      equity = this.evaluator.equity(hole, board, numOpp, 700);
      prior  = this.model.holecardPrior(hole);
      const wp=Math.round((equity?.win||0)*100);
      const idx=wp>=80?4:wp>=62?3:wp>=46?2:wp>=30?1:0;
      const icons=['🚨','⚠️','⚖️','✅','🔥'];
      const labels=[['FOLD','af'],['CAUTION','ac'],['CHECK/CALL','ac'],['CALL/RAISE','ar'],['RAISE','ar']];
      const texts=[
        `${handResult.name} — low equity, fold unless bluffing.`,
        `${handResult.name} — below break-even, be cautious.`,
        `${handResult.name} — marginal, see cheap cards.`,
        `${handResult.name} — good equity, play for value.`,
        `${handResult.name} — strong! Build the pot.`
      ];
      advice=`${icons[idx]} ${texts[idx]}<br><span class="abad ${labels[idx][1]}">${labels[idx][0]}</span>`;
      if (prior) {
        advice+=`<br><span style="color:#aa88ff;font-size:9px;margin-top:3px;display:block">Historical WR on ${prior.key}: ${Math.round(prior.rate*100)}% (${prior.samples} hands)</span>`;
      }
    } else if (this.recentReveals.length > 0) {
      advice=`👁 Observing — ${this.recentReveals.length} reveals logged.`;
    }

    const players=this.players.map(name=>({name,cl:this.profiler.classify(name)}));
    this.overlay.update({street,hole,board,handResult,equity,prior,advice,players,reveals:this.recentReveals,stats:this.store.stats(),isSeated});
  }
}

setTimeout(() => { window.__psk = new PokerSidekick(); }, 2500);
