#!/usr/bin/env bash
# ╔═══════════════════════════════════════════════════════════╗
# ║         TORN POKER SIDEKICK — ONE-CLICK INSTALLER         ║
# ║         Just run this. Everything happens automatically.  ║
# ╚═══════════════════════════════════════════════════════════╝

set -e

# ── Colors ──────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${CYAN}[INFO]${RESET}  $1"; }
success() { echo -e "${GREEN}[OK]${RESET}    $1"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET}  $1"; }
error()   { echo -e "${RED}[ERROR]${RESET} $1"; exit 1; }
banner()  { echo -e "\n${BOLD}${CYAN}$1${RESET}\n"; }

# ── Detect OS ───────────────────────────────────────────────
OS="unknown"
case "$OSTYPE" in
  darwin*)  OS="mac" ;;
  linux*)   OS="linux" ;;
  msys*|cygwin*|win32*) OS="windows" ;;
esac

# ── Find script location ─────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/.poker-sidekick"

banner "♠  TORN POKER SIDEKICK INSTALLER"
echo -e "   Installing to: ${BOLD}$INSTALL_DIR${RESET}"
echo -e "   Detected OS:   ${BOLD}$OS${RESET}"
echo ""

# ── Step 1: Copy files ───────────────────────────────────────
info "Copying files to install directory..."
mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR/extension" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/dashboard" "$INSTALL_DIR/"
success "Files installed to $INSTALL_DIR"

# ── Step 2: Open dashboard in browser ───────────────────────
DASHBOARD="$INSTALL_DIR/dashboard/index.html"
info "Opening dashboard..."
case "$OS" in
  mac)     open "$DASHBOARD" ;;
  linux)   xdg-open "$DASHBOARD" 2>/dev/null || sensible-browser "$DASHBOARD" 2>/dev/null || warn "Open manually: $DASHBOARD" ;;
  windows) start "$DASHBOARD" ;;
  *)       warn "Open manually: $DASHBOARD" ;;
esac
success "Dashboard opened"

# ── Step 3: Print extension install instructions ─────────────
banner "📦  INSTALL THE CHROME EXTENSION (30 seconds)"

echo -e "  ${BOLD}1.${RESET} Open Chrome and go to:"
echo -e "     ${YELLOW}chrome://extensions/${RESET}"
echo ""
echo -e "  ${BOLD}2.${RESET} Enable ${BOLD}Developer Mode${RESET} (toggle in top-right corner)"
echo ""
echo -e "  ${BOLD}3.${RESET} Click ${BOLD}\"Load unpacked\"${RESET}"
echo ""
echo -e "  ${BOLD}4.${RESET} Select this folder:"
echo -e "     ${GREEN}$INSTALL_DIR/extension${RESET}"
echo ""
echo -e "  ${BOLD}5.${RESET} Go to Torn poker:"
echo -e "     ${YELLOW}https://www.torn.com/page.php?sid=holdem${RESET}"
echo -e "     ${YELLOW}https://www.torn.com/page.php?sid=holdemFull${RESET}"
echo ""
echo -e "  The sidekick overlay will appear automatically. ♠"
echo ""

# ── Step 4: Try to auto-open Chrome extensions page ─────────
info "Attempting to open Chrome extensions page for you..."
CHROME_CMD=""
case "$OS" in
  mac)
    for c in "Google Chrome" "Chromium" "Brave Browser"; do
      if open -Ra "$c" 2>/dev/null; then CHROME_CMD="open -a \"$c\""; break; fi
    done
    if [ -n "$CHROME_CMD" ]; then
      eval "$CHROME_CMD" "chrome://extensions/" 2>/dev/null || true
      success "Chrome opened — enable Developer Mode and load the extension folder shown above"
    fi
    ;;
  linux)
    for c in google-chrome chromium chromium-browser brave-browser; do
      if command -v $c &>/dev/null; then
        $c "chrome://extensions/" &>/dev/null &
        success "Chrome opened"
        break
      fi
    done
    ;;
  windows)
    start chrome "chrome://extensions/" 2>/dev/null || true
    ;;
esac

# ── Step 5: Create desktop shortcut for dashboard ───────────
info "Creating dashboard shortcut..."
case "$OS" in
  mac)
    SHORTCUT="$HOME/Desktop/Poker Sidekick.command"
    echo "#!/bin/bash
open \"$DASHBOARD\"" > "$SHORTCUT"
    chmod +x "$SHORTCUT"
    success "Desktop shortcut created: Poker Sidekick.command"
    ;;
  linux)
    SHORTCUT="$HOME/Desktop/poker-sidekick.desktop"
    cat > "$SHORTCUT" << EOF
[Desktop Entry]
Name=Poker Sidekick
Comment=Torn Poker Analysis Dashboard
Exec=xdg-open $DASHBOARD
Icon=applications-games
Terminal=false
Type=Application
Categories=Game;
EOF
    chmod +x "$SHORTCUT" 2>/dev/null || true
    success "Desktop shortcut created"
    ;;
  windows)
    warn "Windows: manually bookmark $DASHBOARD in your browser"
    ;;
esac

# ── Done ─────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════${RESET}"
echo -e "${GREEN}${BOLD}  ✅  INSTALLATION COMPLETE${RESET}"
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════${RESET}"
echo ""
echo -e "  Dashboard:  ${YELLOW}$DASHBOARD${RESET}"
echo -e "  Extension:  ${YELLOW}$INSTALL_DIR/extension${RESET}"
echo ""
echo -e "  ${BOLD}Quick Start:${RESET}"
echo -e "  1. Load the extension (instructions above)"
echo -e "  2. Go to Torn.com poker"
echo -e "  3. The overlay appears — start playing!"
echo -e "  4. Export hands → import to dashboard → train model"
echo ""
