// Torn Poker Sidekick v3 — background service worker
// Just a relay; all logic lives in content.js
let cached = {};
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg.type === 'STATE')  { cached = msg; reply({ ok: true }); }
  if (msg.type === 'GET')    { reply(cached); }
  return true;
});
