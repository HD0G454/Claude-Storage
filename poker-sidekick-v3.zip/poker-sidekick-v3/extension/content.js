// ================================================================
// TORN POKER SIDEKICK v3.0 — Content Script
// ================================================================
// PRIMARY DATA SOURCE: Game log text (richest, most reliable)
// SECONDARY:          DOM card elements (for hole cards while seated)
//
// LOG FORMAT DECODED:
//   "PlayerName called $100,000"
//   "PlayerName raises to $200,000"
//   "PlayerName folds"
//   "PlayerName checks"
//   "PlayerName reveals [K♦, 7♥] (Two Pairs: Sevens and Sixes)"
//   "PlayerName wins $300,000"
//
// CARD FORMAT (in reveals):     [K♦, 7♥]   [A♠, A♣]   [10♥, 2♦]
//
// DOM CARD FORMAT (CSS Modules):
//   class="spades-A___XYZ"   hearts-K___ABC   diamonds-10___QRS
//   Pattern: /(spades|hearts|diamonds|clubs)-(A|K|Q|J|10|[2-9])/
//
// ================================================================
'use strict';

// ── Suit maps ────────────────────────────────────────────────────
const SYM_TO_SUIT = { '♠':'spades','♥':'hearts','♦':'diamonds','♣':'clubs',
                      's':'spades','h':'hearts','d':'diamonds','c':'clubs' };
const SUIT_SYM    = { spades:'♠', hearts:'♥', diamonds:'♦', clubs:'♣' };
const SUIT_COLOR  = { spades:'black', hearts:'red', diamonds:'red', clubs:'black' };
const RANK_VAL    = { '2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,
                      '10':10,'T':10,'J':11,'Q':12,'K':13,'A':14 };

// DOM card regex — matches "diamonds-6" inside any CSS-module class string
const DOM_CARD_RE = /(spades|hearts|diamonds|clubs)-(A|K|Q|J|10|[2-9])/;

// Log card regex — matches ♦, ♥, ♠, ♣ unicode suit symbols after rank
// Handles: K♦  7♥  10♠  A♣  J♦
const LOG_CARD_RE = /\b(10|[2-9AKQJ]|T)([♠♥♦♣])/g;

// Reveal line: "PlayerName  reveals [K♦, 7♥] (Two Pairs: Sevens and Sixes)"
// Note: Torn sometimes uses double-space before "reveals"
const REVEAL_RE = /^(.+?)\s{1,2}reveals\s+\[([^\]]+)\](?:\s+\(([^)]+)\))?/;

// Action line
const ACTION_RE = /^(.+?)\s+(called?|raises? to|raised? to|bets?|folds?|checks?|goes all-in|wins?)\s*\$?([\d,]+)?/i;

// Board cards line (community) — e.g. "Board: [A♠ K♦ 7♣ 2♥ Q♦]"  or inline in log
const BOARD_RE = /Board[:\s]+\[([^\]]+)\]/i;

// ================================================================
// LOG PARSER
// ================================================================
class LogParser {
  constructor() {
    this.seenLines = new Set();
  }

  // Parse raw card string like "K♦" or "10♥" into {rank, suit}
  parseCard(str) {
    str = str.trim();
    const m = str.match(/^(10|[2-9AKQJT])([♠♥♦♣shdc])$/i);
    if (!m) return null;
    let rank = m[1].toUpperCase();
    if (rank === 'T') rank = '10';
    const suit = SYM_TO_SUIT[m[2]] || SYM_TO_SUIT[m[2].toLowerCase()];
    if (!suit) return null;
    return { rank, suit };
  }

  // Parse "[K♦, 7♥]" → [{rank:'K',suit:'diamonds'}, {rank:'7',suit:'hearts'}]
  parseCardList(bracketContent) {
    const cards = [];
    // Split by comma or space, filter empties
    const tokens = bracketContent.replace(/[\[\]]/g, '').split(/[,\s]+/).filter(Boolean);
    for (const t of tokens) {
      const c = this.parseCard(t);
      if (c) cards.push(c);
    }
    return cards;
  }

  // Parse all new lines from the log element
  // Returns array of parsed event objects
  parseNewLines(lines) {
    const events = [];
    for (const raw of lines) {
      const line = raw.trim();
      if (!line || this.seenLines.has(line)) continue;
      this.seenLines.add(line);

      // Reveal line — highest value, has hole cards + hand name
      const revealM = REVEAL_RE.exec(line);
      if (revealM) {
        const player = revealM[1].trim();
        const cards  = this.parseCardList(revealM[2]);
        const handName = revealM[3] || '';
        if (cards.length >= 2) {
          events.push({ type: 'reveal', player, cards, handName, raw: line });
          continue;
        }
      }

      // Board line
      const boardM = BOARD_RE.exec(line);
      if (boardM) {
        const cards = this.parseCardList(boardM[1]);
        if (cards.length >= 3) {
          events.push({ type: 'board', cards, raw: line });
          continue;
        }
      }

      // Action line
      const actM = ACTION_RE.exec(line);
      if (actM) {
        const player = actM[1].trim();
        const rawAction = actM[2].toLowerCase();
        const amount = actM[3] ? parseInt(actM[3].replace(/,/g, '')) : 0;
        let action = 'unknown';
        if (/fold/.test(rawAction))   action = 'fold';
        if (/call/.test(rawAction))   action = 'call';
        if (/raise|bet/.test(rawAction)) action = 'raise';
        if (/check/.test(rawAction))  action = 'check';
        if (/all.in/.test(rawAction)) action = 'raise';
        if (/win/.test(rawAction))    action = 'win';
        events.push({ type: 'action', player, action, amount, raw: line });
        continue;
      }

      // Street markers
      if (/\*\*\*\s*(HOLE CARDS|FLOP|TURN|RIVER|SHOWDOWN|SUMMARY)/i.test(line) ||
          /^-{3,}/.test(line) ||
          /Dealing (flop|turn|river|hole cards)/i.test(line)) {
        let street = 'preflop';
        if (/flop/i.test(line))    street = 'flop';
        if (/turn/i.test(line))    street = 'turn';
        if (/river/i.test(line))   street = 'river';
        if (/showdown|summary/i.test(line)) street = 'showdown';
        events.push({ type: 'street', street, raw: line });
        continue;
      }

      // New hand marker
      if (/Hand\s*#?\d|New hand|Starting hand|Game #/i.test(line)) {
        events.push({ type: 'new_hand', raw: line });
        continue;
      }

      // Win/pot line
      if (/wins?\s+\$?([\d,]+)/i.test(line)) {
        const wm = line.match(/^(.+?)\s+wins?\s+\$?([\d,]+)/i);
        if (wm) {
          events.push({ type: 'action', player: wm[1].trim(), action: 'win',
                        amount: parseInt(wm[2].replace(/,/g,'')) || 0, raw: line });
        }
      }
    }
    return events;
  }
}

// ================================================================
// HAND STATE MACHINE
// Assembles events into complete Hand objects
// ================================================================
class HandAssembler {
  constructor() {
    this.reset();
  }

  reset() {
    this.hand = {
      id: Date.now() + Math.random(),
      ts: new Date().toISOString(),
      street: 'preflop',
      board: [],
      players: {},   // name → {cards, handName, actions:[]}
      actions: [],   // [{street, player, action, amount}]
      winners: [],
      heroCards: null,
      complete: false,
      isObserved: true  // was watching, not playing
    };
    this.currentStreet = 'preflop';
  }

  ingest(event) {
    const h = this.hand;

    if (event.type === 'new_hand') {
      // Save old hand if it had any reveals, then reset
      const old = this.finalise();
      this.reset();
      return old;
    }

    if (event.type === 'street') {
      this.currentStreet = event.street;
      h.street = event.street;
    }

    if (event.type === 'board') {
      h.board = event.cards;
    }

    if (event.type === 'reveal') {
      if (!h.players[event.player]) h.players[event.player] = { cards:[], handName:'', actions:[] };
      h.players[event.player].cards    = event.cards;
      h.players[event.player].handName = event.handName;
    }

    if (event.type === 'action') {
      if (!h.players[event.player]) h.players[event.player] = { cards:[], handName:'', actions:[] };
      h.players[event.player].actions.push({ street: this.currentStreet, action: event.action, amount: event.amount });
      h.actions.push({ street: this.currentStreet, player: event.player, action: event.action, amount: event.amount });
      if (event.action === 'win') h.winners.push(event.player);
    }
  }

  finalise() {
    const h = this.hand;
    // Only save if we have at least one reveal (real hand data)
    if (Object.keys(h.players).length === 0) return null;
    if (!Object.values(h.players).some(p => p.cards.length >= 2)) return null;
    h.complete = true;
    return { ...h };
  }
}

// ================================================================
// OPPONENT PROFILER
// ================================================================
class OpponentProfiler {
  constructor() {
    this.profiles = {};
    this._load();
  }
  _load() {
    try { this.profiles = JSON.parse(localStorage.getItem('psk_opponents') || '{}'); } catch(e){}
  }
  save() {
    try { localStorage.setItem('psk_opponents', JSON.stringify(this.profiles)); } catch(e){}
  }
  get(name) {
    if (!this.profiles[name]) {
      this.profiles[name] = { name, actions:[], reveals:[], handsPlayed:0, wins:0, lastSeen:0 };
    }
    return this.profiles[name];
  }
  recordAction(name, action, street, amount) {
    const p = this.get(name);
    p.actions.push({ action, street, amount, ts: Date.now() });
    if (p.actions.length > 2000) p.actions = p.actions.slice(-2000);
    p.lastSeen = Date.now();
  }
  recordReveal(name, cards, handName, won) {
    const p = this.get(name);
    p.reveals.push({ cards, handName, won, ts: Date.now() });
    if (p.reveals.length > 500) p.reveals = p.reveals.slice(-500);
    p.handsPlayed++;
    if (won) p.wins++;
  }
  classify(name) {
    const p = this.get(name);
    const a = p.actions;
    if (a.length < 6) return { label:'Unknown', icon:'❓', color:'#556677', vpip:null, pfr:null, af:null };
    const tot = a.length;
    const rz  = a.filter(x => x.action === 'raise').length;
    const cl  = a.filter(x => x.action === 'call').length;
    const fd  = a.filter(x => x.action === 'fold').length;
    const vpip = Math.round((rz + cl) / tot * 100);
    const pfr  = Math.round(rz / tot * 100);
    const af   = cl > 0 ? +(rz / cl).toFixed(1) : rz > 0 ? '∞' : 0;
    const rr   = rz / tot, fr = fd / tot;
    let label, icon, color;
    if (rr > 0.42)               { label='Maniac';    icon='💣'; color='#ff2244'; }
    else if (rr>0.26 && fr<0.40) { label='Aggressive';icon='🔥'; color='#ff6030'; }
    else if (fr > 0.68)          { label='Nit';       icon='🐢'; color='#3090ff'; }
    else if (rr>0.18 && fr<0.46) { label='TAG';       icon='🎯'; color='#00e887'; }
    else if (rr<0.10 && fr<0.32) { label='Station';   icon='📞'; color='#ffcc00'; }
    else if (fr > 0.50)          { label='Passive';   icon='👻'; color='#8899aa'; }
    else                         { label='Balanced';  icon='⚖️'; color='#aa88ff'; }
    return { label, icon, color, vpip, pfr, af, handsPlayed: p.handsPlayed, wins: p.wins };
  }
}

// ================================================================
// HAND EVALUATOR + MONTE CARLO
// ================================================================
class HandEvaluator {
  eval(hole, board) {
    const all = [...(hole||[]), ...(board||[])];
    if (all.length < 2) return { rank:-1, name:'—', strength:0 };
    const k = Math.min(5, all.length);
    let best = { rank:-1, name:'', strength:0 };
    for (const c of this._combos(all, k)) {
      const r = this._eval5(c);
      if (r.rank > best.rank || (r.rank===best.rank && r.strength>best.strength)) best = r;
    }
    return best;
  }

  _eval5(cards) {
    const rv = c => RANK_VAL[c.rank] || parseInt(c.rank) || 0;
    const ranks = cards.map(rv).sort((a,b)=>b-a);
    const suits = cards.map(c=>c.suit);
    const isF   = suits.length>=5 && suits.every(s=>s===suits[0]);
    const rc    = {}; ranks.forEach(r=>rc[r]=(rc[r]||0)+1);
    const cnts  = Object.values(rc).sort((a,b)=>b-a);
    const isSt  = this._straight(ranks);
    if (isF&&isSt&&ranks[0]===14) return {rank:9,name:'Royal Flush',  strength:1.000};
    if (isF&&isSt)                return {rank:8,name:'Straight Flush',strength:.970+ranks[0]/1e3};
    if (cnts[0]===4)              return {rank:7,name:'Four of a Kind',strength:.940+ranks[0]/1e3};
    if (cnts[0]===3&&cnts[1]===2)return {rank:6,name:'Full House',    strength:.910+ranks[0]/1e3};
    if (isF)                      return {rank:5,name:'Flush',         strength:.820+ranks[0]/1e3};
    if (isSt)                     return {rank:4,name:'Straight',      strength:.720+ranks[0]/1e3};
    if (cnts[0]===3)              return {rank:3,name:'Three of a Kind',strength:.620+ranks[0]/1e3};
    if (cnts[0]===2&&cnts[1]===2)return {rank:2,name:'Two Pair',      strength:.480+ranks[0]/1e3};
    if (cnts[0]===2) {
      const pr=+Object.entries(rc).find(([,v])=>v===2)?.[0]||0;
      return {rank:1,name:'One Pair',strength:.32+pr/100};
    }
    return {rank:0,name:'High Card',strength:ranks[0]/100};
  }

  _straight(s) {
    if (s.length<5) return false;
    const t=s.slice(0,5);
    if (t[0]-t[4]===4&&new Set(t).size===5) return true;
    // Wheel A-2-3-4-5
    if (s[0]===14&&s[s.length-1]===2&&s.slice(1,5).join()===s.filter(r=>r<=5).slice(0,4).join()) return true;
    return false;
  }

  _combos(arr,k) {
    if (k>=arr.length) return [arr];
    if (k===1) return arr.map(x=>[x]);
    const r=[];
    for (let i=0;i<=arr.length-k;i++)
      this._combos(arr.slice(i+1),k-1).forEach(t=>r.push([arr[i],...t]));
    return r;
  }

  equity(hole, board, numOpp=1, sims=800) {
    if (!hole||hole.length<2) return null;
    const deck = this._buildDeck([...hole,...(board||[])]);
    let wins=0, ties=0;
    for (let i=0;i<sims;i++) {
      const d = this._shuffle([...deck]);
      const needed = 5-(board||[]).length;
      const brd = [...(board||[]),...d.slice(0,needed)];
      const mine = this.eval(hole,brd);
      let iWin=true,isTie=false; let ptr=needed;
      for (let o=0;o<numOpp;o++) {
        const oh=d.slice(ptr,ptr+2); ptr+=2;
        if (oh.length<2) break;
        const opp=this.eval(oh,brd);
        if (opp.rank>mine.rank||(opp.rank===mine.rank&&opp.strength>mine.strength)){iWin=false;break;}
        if (opp.rank===mine.rank&&Math.abs(opp.strength-mine.strength)<.001) isTie=true;
      }
      if (iWin&&!isTie) wins++;
      else if (isTie) ties++;
    }
    return { win:wins/sims, tie:ties/sims, lose:(sims-wins-ties)/sims };
  }

  _buildDeck(exclude) {
    const ranks=['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
    const suits=['spades','hearts','diamonds','clubs'];
    const ex=new Set(exclude.map(c=>c.rank+'|'+c.suit));
    const d=[];
    for (const r of ranks) for (const s of suits)
      if (!ex.has(r+'|'+s)) d.push({rank:r,suit:s});
    return d;
  }

  _shuffle(a) {
    for (let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}
    return a;
  }
}

// ================================================================
// HAND STORE
// ================================================================
class HandStore {
  constructor() {
    this.hands = [];
    this._load();
  }
  _load() {
    try { this.hands = JSON.parse(localStorage.getItem('psk_hands')||'[]'); } catch(e){}
  }
  save() {
    try { localStorage.setItem('psk_hands', JSON.stringify(this.hands.slice(-5000))); } catch(e){}
  }
  add(hand) {
    // Dedupe by id
    if (this.hands.find(h=>h.id===hand.id)) return;
    this.hands.push(hand);
    this.save();
  }
  stats() {
    const t = this.hands.length;
    const heroHands = this.hands.filter(h=>!h.isObserved);
    const hw = heroHands.filter(h=>h.winners.includes('hero')||h.winners.includes(h.heroName)).length;
    return {
      total: t,
      observed: this.hands.filter(h=>h.isObserved).length,
      heroHands: heroHands.length,
      heroWins: hw,
      heroWinRate: heroHands.length ? (hw/heroHands.length*100).toFixed(1) : '0'
    };
  }
  export() { return JSON.stringify(this.hands, null, 2); }
}

// ================================================================
// DOM CARD SCRAPER (secondary — for hero hole cards while seated)
// ================================================================
function scrapeHeroCards() {
  const holeCards = [];
  // Find all elements whose class contains a card descriptor
  const all = document.querySelectorAll('[class*="___"]');
  for (const el of all) {
    const m = DOM_CARD_RE.exec(el.className);
    if (!m) continue;
    const card = { rank: m[2], suit: m[1] };

    // Walk up to determine if this is a hole card (belongs to hero seat)
    let node = el, isHole = false;
    for (let i=0;i<10;i++) {
      node = node.parentElement;
      if (!node) break;
      const cls = (node.className||'').toLowerCase() + (node.id||'').toLowerCase();
      if (/hole|pocket|hero|self|mycard|yourcard|handcard/.test(cls)) { isHole=true; break; }
      // Stop if we hit community card territory
      if (/community|board|shared|flop|turn|river/.test(cls)) break;
    }
    if (isHole && holeCards.length < 2) holeCards.push(card);
  }
  return holeCards;
}

// Scrape community cards from DOM
function scrapeBoardCards() {
  const board = [];
  const all = document.querySelectorAll('[class*="___"]');
  for (const el of all) {
    const m = DOM_CARD_RE.exec(el.className);
    if (!m) continue;
    let node = el, isBoard = false;
    for (let i=0;i<10;i++) {
      node = node.parentElement;
      if (!node) break;
      const cls = (node.className||'').toLowerCase();
      if (/community|board|shared|flop|turn|river/.test(cls)) { isBoard=true; break; }
      if (/hole|pocket|hero|self/.test(cls)) break;
    }
    if (isBoard && board.length < 5) board.push({ rank: m[2], suit: m[1] });
  }
  return board;
}

// Scrape pot size from DOM
function scrapePot() {
  const pots = document.querySelectorAll('[class*="pot" i], [class*="Pot"]');
  let best = 0;
  for (const el of pots) {
    const n = parseInt((el.textContent||'').replace(/[^0-9]/g,''));
    if (n > best) best = n;
  }
  return best;
}

// ================================================================
// MINI BAYESIAN MODEL
// Learns which hands/situations win; improves with each new hand
// ================================================================
class BayesModel {
  constructor() {
    this.data = { handWins:{}, handTotal:{}, oppFoldRate:{}, positionWins:{}, positionTotal:{} };
    this._load();
  }
  _load() {
    try { this.data = JSON.parse(localStorage.getItem('psk_model_data')||'{}');
      this.data.handWins    = this.data.handWins    || {};
      this.data.handTotal   = this.data.handTotal   || {};
      this.data.oppFoldRate = this.data.oppFoldRate || {};
      this.data.positionWins  = this.data.positionWins  || {};
      this.data.positionTotal = this.data.positionTotal || {};
    } catch(e){}
  }
  save() { try { localStorage.setItem('psk_model_data', JSON.stringify(this.data)); } catch(e){} }

  // Record a completed hand into the model
  learn(hand, evaluator) {
    const players = Object.entries(hand.players);
    if (players.length === 0) return;

    for (const [name, pdata] of players) {
      if (pdata.cards.length < 2) continue;
      const won = hand.winners.includes(name);
      const ev  = evaluator.eval(pdata.cards, hand.board);

      // Hand strength bucket (0–9 rank)
      const bucket = `rank_${ev.rank}`;
      this.data.handWins[bucket]  = (this.data.handWins[bucket]  || 0) + (won?1:0);
      this.data.handTotal[bucket] = (this.data.handTotal[bucket] || 0) + 1;

      // Hole card key e.g. "AK_suited"
      const [c1,c2] = [...pdata.cards].sort((a,b)=>RANK_VAL[b.rank]-RANK_VAL[a.rank]);
      const suited = c1.suit===c2.suit?'s':'o';
      const hkey = `${c1.rank}${c2.rank}_${suited}`;
      this.data.handWins[hkey]  = (this.data.handWins[hkey]  || 0) + (won?1:0);
      this.data.handTotal[hkey] = (this.data.handTotal[hkey] || 0) + 1;
    }
    this.save();
  }

  // Estimate win probability bonus for a known hole card combo
  holecardPrior(hole) {
    if (!hole||hole.length<2) return null;
    const [c1,c2]=[...hole].sort((a,b)=>RANK_VAL[b.rank]-RANK_VAL[a.rank]);
    const s=c1.suit===c2.suit?'s':'o';
    const key=`${c1.rank}${c2.rank}_${s}`;
    const wins=this.data.handWins[key]||0;
    const tot=this.data.handTotal[key]||0;
    if (tot<3) return null;
    return { rate: wins/tot, samples: tot, key };
  }

  accuracy() {
    let ok=0,tot=0;
    const HAND_RANKS=['rank_0','rank_1','rank_2','rank_3','rank_4','rank_5','rank_6','rank_7','rank_8','rank_9'];
    for (const key of HAND_RANKS) {
      const w=this.data.handWins[key]||0, t=this.data.handTotal[key]||0;
      if (t===0) continue;
      // Expected: rank ≥4 should win >50%
      const wr=w/t, expected=key>='rank_4'?1:0, predicted=wr>.5?1:0;
      if (predicted===expected) ok++; tot++;
    }
    return tot>0?ok/tot:null;
  }
}

// ================================================================
// OVERLAY UI
// ================================================================
class Overlay {
  constructor() {
    this._inject();
  }

  _inject() {
    document.getElementById('psk')?.remove();
    document.getElementById('psk-css')?.remove();

    const style = document.createElement('style');
    style.id='psk-css';
    style.textContent=this._css();
    document.head.appendChild(style);

    const root=document.createElement('div');
    root.id='psk';
    root.innerHTML=this._html();
    document.body.appendChild(root);
    this._bind(root);
    this.root=root;
  }

  _html() { return `
<div id="psk-box">
  <div id="psk-hdr">
    <span id="psk-logo">♠ SIDEKICK</span>
    <div>
      <span id="psk-obs-badge" title="Observing">👁</span>
      <span id="psk-min" title="Minimize">─</span>
    </div>
  </div>
  <div id="psk-body">

    <div class="pl">STREET</div>
    <div id="psk-street">Watching...</div>

    <div class="pl" style="margin-top:8px">YOUR CARDS</div>
    <div id="psk-hole" class="psk-crow">
      <span class="pce">?</span><span class="pce">?</span>
    </div>

    <div class="pl" style="margin-top:6px">BOARD</div>
    <div id="psk-board" class="psk-crow">
      <span class="pce">?</span><span class="pce">?</span>
      <span class="pce">?</span><span class="pce">?</span><span class="pce">?</span>
    </div>

    <div id="psk-handname">—</div>

    <div id="psk-eq-wrap">
      <div id="psk-eq-bar-bg"><div id="psk-eq-bar"></div></div>
      <div id="psk-eq-nums">
        <div><span id="eq-w">—</span><div class="el">WIN</div></div>
        <div><span id="eq-t">—</span><div class="el">TIE</div></div>
        <div><span id="eq-l">—</span><div class="el">LOSE</div></div>
      </div>
    </div>

    <div id="psk-prior"></div>
    <div id="psk-advice"></div>

    <div class="pl" style="margin-top:8px">AT TABLE</div>
    <div id="psk-opps"></div>

    <div id="psk-log-section">
      <div class="pl" style="margin-top:8px">LAST REVEALS</div>
      <div id="psk-reveals"></div>
    </div>

    <div id="psk-foot">
      <span id="psk-stat">0 hands</span>
      <button id="psk-exp">⬇ Export</button>
    </div>
  </div>
</div>`; }

  _css() { return `
#psk{position:fixed;top:80px;right:16px;z-index:2147483647;font-family:'Courier New',monospace;font-size:11px;user-select:none;}
#psk-box{width:220px;background:#08101e;border:1px solid #1a3a5c;border-radius:10px;
  box-shadow:0 0 28px rgba(0,180,255,.1),0 4px 24px rgba(0,0,0,.7);overflow:hidden;}
#psk-hdr{display:flex;justify-content:space-between;align-items:center;
  padding:7px 11px;background:#0b1828;border-bottom:1px solid #1a3a5c;cursor:move;}
#psk-logo{color:#00c8ff;font-weight:bold;font-size:10px;letter-spacing:2.5px;}
#psk-hdr div{display:flex;gap:8px;align-items:center;}
#psk-obs-badge{font-size:13px;cursor:default;}
#psk-min{color:#00c8ff;cursor:pointer;font-size:15px;line-height:1;}
#psk-min:hover{color:#fff;}
#psk-body{padding:9px 10px;}
#psk-box.mini #psk-body{display:none;}
.pl{font-size:8px;letter-spacing:2px;color:#2a5070;margin-bottom:3px;}
#psk-street{color:#00c8ff;font-size:10px;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:4px;}
.psk-crow{display:flex;gap:3px;flex-wrap:wrap;margin-bottom:2px;}
.pc{display:inline-flex;flex-direction:column;align-items:center;justify-content:center;
  width:32px;height:44px;background:#fff;border-radius:4px;
  font-family:Georgia,serif;font-weight:bold;box-shadow:0 2px 6px rgba(0,0,0,.5);
  transition:transform .15s;line-height:1;}
.pc:hover{transform:translateY(-3px);}
.pc .pr{font-size:12px;}.pc .ps{font-size:11px;}
.pc.red{color:#cc0000;}.pc.black{color:#111133;}
.pc.hole{border:2px solid #ffcc00;}
.pce{display:inline-flex;align-items:center;justify-content:center;
  width:32px;height:44px;background:#0d1e30;border:1px solid #1a3a5c;
  border-radius:4px;color:#1a3a5c;font-size:16px;}
#psk-handname{font-size:13px;font-weight:bold;color:#fff;margin:8px 0 5px;letter-spacing:.3px;}
#psk-eq-wrap{margin-bottom:7px;}
#psk-eq-bar-bg{height:5px;background:#0d1e30;border-radius:3px;overflow:hidden;margin-bottom:5px;}
#psk-eq-bar{height:100%;width:0;border-radius:3px;transition:width .5s,background .5s;
  background:linear-gradient(90deg,#004418,#00e887);}
#psk-eq-nums{display:grid;grid-template-columns:1fr 1fr 1fr;text-align:center;font-size:11px;font-weight:bold;}
#psk-eq-nums>div{display:flex;flex-direction:column;align-items:center;}
#eq-w{color:#00e887;}#eq-t{color:#ffcc00;}#eq-l{color:#ff4060;}
.el{font-size:7px;color:#2a5070;letter-spacing:1px;}
#psk-prior{font-size:10px;color:#aa88ff;margin-bottom:4px;min-height:0;}
#psk-advice{background:#0b1828;border:1px solid #1a3a5c;border-radius:5px;
  padding:6px 8px;margin:6px 0;font-size:10px;color:#c0d8e8;line-height:1.45;min-height:28px;}
.abad{display:inline-block;margin-top:4px;padding:1px 8px;border-radius:3px;
  font-size:9px;font-weight:bold;letter-spacing:1px;}
.af{background:#3a0010;color:#ff4060;border:1px solid #ff4060;}
.ac{background:#3a2e00;color:#ffcc00;border:1px solid #ffcc00;}
.ar{background:#003a15;color:#00e887;border:1px solid #00e887;}
.psk-opp{display:flex;align-items:center;justify-content:space-between;
  padding:3px 0;border-bottom:1px solid #0d1e30;font-size:10px;}
.psk-opp:last-child{border:none;}
.psk-on{color:#8899aa;flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;}
.psk-ot{font-size:8px;padding:1px 5px;border-radius:3px;white-space:nowrap;
  margin-left:4px;letter-spacing:.3px;}
.rev-row{font-size:9px;color:#556677;padding:2px 0;border-bottom:1px solid #0d1520;line-height:1.4;}
.rev-row:last-child{border:none;}
.rev-cards{color:#ffcc00;}
.rev-won{color:#00e887;}.rev-lost{color:#ff4060;}
#psk-foot{display:flex;justify-content:space-between;align-items:center;
  border-top:1px solid #1a3a5c;padding-top:6px;margin-top:6px;}
#psk-stat{color:#2a5070;font-size:9px;}
#psk-exp{background:#0b1828;border:1px solid #1a3a5c;color:#00c8ff;
  padding:2px 8px;border-radius:3px;cursor:pointer;font-family:'Courier New',monospace;
  font-size:9px;letter-spacing:1px;}
#psk-exp:hover{background:#1a3a5c;}
`; }

  _bind(root) {
    // Dragging
    let drag=false,ox=0,oy=0;
    root.querySelector('#psk-hdr').addEventListener('mousedown',e=>{
      drag=true;ox=e.clientX-root.offsetLeft;oy=e.clientY-root.offsetTop;e.preventDefault();
    });
    document.addEventListener('mousemove',e=>{ if(!drag)return;
      root.style.right='auto';
      root.style.left=Math.max(0,e.clientX-ox)+'px';
      root.style.top=Math.max(0,e.clientY-oy)+'px';
    });
    document.addEventListener('mouseup',()=>drag=false);
    root.querySelector('#psk-min').addEventListener('click',()=>
      root.querySelector('#psk-box').classList.toggle('mini'));
  }

  cardHTML(c, isHole=false) {
    const sym=SUIT_SYM[c.suit]||c.suit;
    const col=SUIT_COLOR[c.suit]||'black';
    return `<span class="pc ${col}${isHole?' hole':''}">
      <span class="pr">${c.rank}</span><span class="ps">${sym}</span>
    </span>`;
  }

  cardStr(c) { return c.rank+(SUIT_SYM[c.suit]||c.suit[0]); }

  update({street,hole,board,handResult,equity,prior,advice,players,reveals,stats,isSeated}) {
    const $=id=>document.getElementById(id);

    // Observation badge
    $('psk-obs-badge').textContent = isSeated ? '🪑' : '👁';
    $('psk-obs-badge').title       = isSeated ? 'Seated & playing' : 'Observing only';

    // Street
    const smap={preflop:'PRE-FLOP',flop:'FLOP',turn:'TURN',river:'RIVER',showdown:'SHOWDOWN'};
    $('psk-street').textContent = smap[street] || 'WAITING...';

    // Hole cards
    const hd=$('psk-hole');
    hd.innerHTML = (hole||[]).length>=2
      ? hole.map(c=>this.cardHTML(c,true)).join('')
      : '<span class="pce">?</span><span class="pce">?</span>';

    // Board
    const bd=$('psk-board');
    let bh=(board||[]).slice(0,5).map(c=>this.cardHTML(c)).join('');
    for(let i=(board||[]).length;i<5;i++) bh+='<span class="pce">?</span>';
    bd.innerHTML=bh;

    // Hand name
    $('psk-handname').textContent=handResult?.name||'—';

    // Equity
    if (equity) {
      const wp=Math.round(equity.win*100);
      const bar=$('psk-eq-bar');
      bar.style.width=wp+'%';
      bar.style.background=wp>65?'linear-gradient(90deg,#003a12,#00e887)'
        :wp>40?'linear-gradient(90deg,#3a2a00,#ffcc00)'
              :'linear-gradient(90deg,#3a0010,#ff4060)';
      $('eq-w').textContent=wp+'%';
      $('eq-t').textContent=Math.round(equity.tie*100)+'%';
      $('eq-l').textContent=Math.round(equity.lose*100)+'%';
    }

    // Prior from model
    const pd=$('psk-prior');
    if (prior) {
      pd.textContent=`Model: ${Math.round(prior.rate*100)}% WR on ${prior.key} (${prior.samples} hands)`;
    } else { pd.textContent=''; }

    // Advice
    $('psk-advice').innerHTML=advice||'🃏 Watching the table...';

    // Opponents
    const od=$('psk-opps');
    if (players&&players.length) {
      od.innerHTML=players.slice(0,6).map(p=>`
        <div class="psk-opp">
          <span class="psk-on" title="${p.name}">${p.name.slice(0,14)}</span>
          <span class="psk-ot" style="background:${p.cl.color}22;color:${p.cl.color};border:1px solid ${p.cl.color}44">
            ${p.cl.icon} ${p.cl.label}
          </span>
        </div>`).join('');
    } else {
      od.innerHTML='<div style="color:#2a5070;font-size:9px;padding:3px 0">Reading table...</div>';
    }

    // Recent reveals
    const rd=$('psk-reveals');
    if (reveals&&reveals.length) {
      rd.innerHTML=reveals.slice(0,5).map(r=>`
        <div class="rev-row">
          <span class="${r.won?'rev-won':'rev-lost'}">${r.won?'✅':'❌'}</span>
          <b style="color:#8899aa"> ${r.player.slice(0,10)}</b>
          <span class="rev-cards"> ${r.cards.map(c=>this.cardStr(c)).join(' ')}</span>
          <span style="color:#445566"> ${r.handName||''}</span>
        </div>`).join('');
    }

    // Footer stats
    $('psk-stat').textContent=`${stats.total} hands (${stats.observed} obs)`;
  }

  setExportHandler(fn) {
    document.getElementById('psk-exp').addEventListener('click', fn);
  }
}

// ================================================================
// MAIN SIDEKICK — ties everything together
// ================================================================
class PokerSidekick {
  constructor() {
    this.parser   = new LogParser();
    this.assembler= new HandAssembler();
    this.profiler = new OpponentProfiler();
    this.evaluator= new HandEvaluator();
    this.store    = new HandStore();
    this.model    = new BayesModel();
    this.overlay  = new Overlay();

    // Live state
    this.currentBoard   = [];
    this.heroHole       = [];
    this.currentStreet  = 'preflop';
    this.recentReveals  = [];   // last 5 reveals for display
    this.currentPlayers = [];   // names seen this hand

    this.overlay.setExportHandler(()=>this._export());
    this._startObserving();

    console.log('%c♠ Torn Poker Sidekick v3.0 — log-first observer active','color:#00c8ff;font-weight:bold;font-size:13px');
  }

  _export() {
    const blob=new Blob([this.store.export()],{type:'application/json'});
    const a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download=`torn_poker_${Date.now()}.json`;
    a.click();
  }

  // ── Find the log container ─────────────────────────────────
  _findLogEl() {
    // Try common Torn log selectors
    const selectors = [
      '[class*="log"]', '[class*="Log"]', '[class*="history"]',
      '[class*="History"]', '[class*="chat"]', '[class*="gamelog"]',
      '[class*="gameLog"]', '[class*="handHistory"]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.textContent.includes('reveals')) return el;
    }
    // Fallback: find any element containing "reveals" text
    const all = document.querySelectorAll('div,ul,ol,section,aside');
    for (const el of all) {
      if (el.children.length > 3 && el.textContent.includes('reveals') &&
          el.textContent.length > 200) return el;
    }
    return null;
  }

  // ── Extract log lines from the log element ─────────────────
  _getLines(logEl) {
    if (!logEl) return [];
    // Prefer individual child elements as lines
    const children = [...logEl.querySelectorAll('p, li, div > span, [class*="line"], [class*="entry"], [class*="msg"]')];
    if (children.length > 0) {
      return children.map(c=>c.textContent.trim()).filter(Boolean);
    }
    // Fallback: split by newline
    return logEl.textContent.split('\n').map(l=>l.trim()).filter(Boolean);
  }

  // ── Process new log events ─────────────────────────────────
  _processEvents(events) {
    for (const ev of events) {

      // Track board from log events
      if (ev.type === 'board') {
        this.currentBoard = ev.cards;
        this.currentStreet = ev.cards.length===3?'flop':ev.cards.length===4?'turn':'river';
      }

      if (ev.type === 'street') {
        this.currentStreet = ev.street;
        if (ev.street === 'preflop') {
          this.currentBoard = [];
          this.recentReveals = [];
        }
      }

      if (ev.type === 'reveal') {
        // Track for display
        this.recentReveals.unshift({
          player: ev.player,
          cards: ev.cards,
          handName: ev.handName,
          won: false  // will be updated by win action
        });
        if (this.recentReveals.length > 8) this.recentReveals.pop();

        // Profile the player's actions leading up to reveal
        this.profiler.get(ev.player); // ensure exists
      }

      if (ev.type === 'action') {
        // Mark winners in recent reveals
        if (ev.action === 'win') {
          this.recentReveals.forEach(r=>{if(r.player===ev.player)r.won=true;});
        }
        this.profiler.recordAction(ev.player, ev.action, this.currentStreet, ev.amount);
        this.profiler.save();
        if (!this.currentPlayers.includes(ev.player)) this.currentPlayers.push(ev.player);
      }

      // Feed into assembler
      const completed = this.assembler.ingest(ev);
      if (completed) {
        this._onHandComplete(completed);
      }
    }
  }

  // ── A full hand has been assembled ────────────────────────
  _onHandComplete(hand) {
    // Record reveals into profiler
    for (const [name, pdata] of Object.entries(hand.players)) {
      if (pdata.cards.length < 2) continue;
      const won = hand.winners.includes(name);
      this.profiler.recordReveal(name, pdata.cards, pdata.handName, won);
    }
    this.profiler.save();

    // Store the hand
    this.store.add(hand);

    // Train model immediately
    this.model.learn(hand, this.evaluator);

    // Broadcast to dashboard
    this._broadcastToDashboard();

    console.log(`[Sidekick] Hand logged: ${Object.keys(hand.players).length} players, winners: ${hand.winners.join(', ')}`);
  }

  // ── Push live state to dashboard via localStorage ──────────
  _broadcastToDashboard() {
    try {
      localStorage.setItem('psk_live', JSON.stringify({
        board: this.currentBoard,
        heroHole: this.heroHole,
        street: this.currentStreet,
        players: this.currentPlayers,
        reveals: this.recentReveals,
        stats: this.store.stats(),
        ts: Date.now()
      }));
    } catch(e) {}
  }

  // ── Main render tick ───────────────────────────────────────
  _render() {
    const hole   = this.heroHole;
    const board  = this.currentBoard;
    const street = this.currentStreet;
    const isSeated = hole.length >= 2;

    let handResult=null, equity=null, prior=null, advice='🃏 Watching the table...';

    if (hole.length >= 2) {
      handResult = this.evaluator.eval(hole, board);
      const numOpp = Math.max(1, this.currentPlayers.length - 1);
      equity = this.evaluator.equity(hole, board, numOpp, 700);
      prior  = this.model.holecardPrior(hole);

      // Advice
      const wp = Math.round((equity?.win||0)*100);
      const icons=['🚨','⚠️','⚖️','✅','🔥'];
      const idx = wp>=80?4:wp>=62?3:wp>=46?2:wp>=30?1:0;
      const labels=[['FOLD','af'],['CAUTION','ac'],['CHECK/CALL','ac'],['CALL/RAISE','ar'],['RAISE','ar']];
      const texts=[
        `${handResult.name} — low equity, fold unless bluffing.`,
        `${handResult.name} — below break-even, be cautious.`,
        `${handResult.name} — marginal, see cheap cards.`,
        `${handResult.name} — good equity, play for value.`,
        `${handResult.name} — strong! Build the pot.`
      ];
      advice=`${icons[idx]} ${texts[idx]}<br><span class="abad ${labels[idx][1]}">${labels[idx][0]}</span>`;

      if (prior) {
        advice += `<br><span style="color:#aa88ff;font-size:9px;margin-top:3px;display:block">
          Historical WR on ${prior.key}: ${Math.round(prior.rate*100)}% (${prior.samples} hands)</span>`;
      }
    } else if (this.recentReveals.length > 0) {
      advice = `👁 Observing — ${this.recentReveals.length} reveals logged this round.`;
    }

    const players = this.currentPlayers.map(name=>({
      name, cl: this.profiler.classify(name)
    }));

    this.overlay.update({
      street, hole, board, handResult, equity, prior, advice,
      players, reveals: this.recentReveals, stats: this.store.stats(), isSeated
    });
  }

  // ── Observation loop ───────────────────────────────────────
  _startObserving() {
    let lastLogLen=0, lastHoleKey='';

    const tick = ()=>{
      try {
        // 1. Scrape hero hole cards (only works when seated)
        const scrapeHole = scrapeHeroCards();
        const holeKey = scrapeHole.map(c=>c.rank+'|'+c.suit).join(',');
        if (holeKey !== lastHoleKey) {
          lastHoleKey = holeKey;
          this.heroHole = scrapeHole;
          if (scrapeHole.length > 0) {
            this.assembler.hand.heroCards = scrapeHole;
            this.assembler.hand.isObserved = false;
          }
        }

        // 2. Also scrape board from DOM (backup if log parsing misses it)
        const domBoard = scrapeBoardCards();
        if (domBoard.length > this.currentBoard.length) this.currentBoard = domBoard;

        // 3. Parse log
        const logEl = this._findLogEl();
        const lines  = this._getLines(logEl);
        if (lines.length !== lastLogLen) {
          lastLogLen = lines.length;
          const newLines = lines.slice(-50); // process last 50 lines
          const events = this.parser.parseNewLines(newLines);
          if (events.length > 0) {
            this._processEvents(events);
            this._broadcastToDashboard();
          }
        }

        // 4. Render
        this._render();

      } catch(err) {
        // Silent — never break Torn's own JS
      }
    };

    setInterval(tick, 1200);

    // MutationObserver for immediate log updates
    setTimeout(()=>{
      const logEl = this._findLogEl();
      if (logEl) {
        new MutationObserver(()=>tick()).observe(logEl,{childList:true,subtree:true,characterData:true});
      }
    }, 3000);
  }
}

// ── Boot after Torn's React has rendered ─────────────────────
setTimeout(()=>{
  window.__psk = new PokerSidekick();
}, 2500);
